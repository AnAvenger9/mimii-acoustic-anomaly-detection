# Five-minute viva script

Target finish **4:40**, leaving 20 seconds for transitions. Stop after slide 8. The last two PowerPoint slides are hidden and available for questions.

## 1. Detecting industrial faults from sound (0:00–0:20)

A faulty fan can still sound like the same fan. Could a system trained on healthy recordings detect that change? I tested whether confidence in the identity of a known machine could serve as a fault signal.

## 2. One recording, three noise mixtures (0:20–0:55)

MIMII contains four machine types and four IDs per type. Each ten-second recording appears at three noise levels. I kept the three versions together to prevent leakage. Each clip became a 128-band log-mel spectrogram, normalized using healthy training audio. Every faulty clip was reserved for testing.

## 3. How a machine ID becomes an alarm (0:55–1:30)

For each machine type, I trained a classifier to identify the unit from healthy audio using cross-entropy. At inference, the microphone’s unit is known. A fall in its predicted probability raises the anomaly score, even if that ID stays on top. I set the alarm cutoff at the ninety-fifth percentile of healthy training scores.

## 4. Five CNNs test three design choices (1:30–2:12)

I started with lightweight MobileNet. ResNet has eight residual blocks and EfficientNet has sixteen bottleneck blocks. I fine-tuned these image-pretrained networks on spectrograms. My two acoustic CNNs each have six residual blocks and summarize both average energy and variation over time. Widening the channels increased parameters sevenfold at the same depth.

## 5. Identity accuracy can hide missed faults (2:12–2:35)

ResNet missed only two healthy validation IDs. Yet its alarm missed about thirty percent of faulty test clips. Even a linear classifier using average spectra recognized most healthy IDs. A machine can retain its distinctive sound during a fault, so we need a separate fault-detection test.

## 6. Three CNNs ranked faults better together (2:35–3:25)

ResNet was stronger on fans, while EfficientNet was stronger on valves. The wide acoustic CNN adds a third view: how much its learned features vary over time. I standardized each model’s log anomaly score against healthy recordings of the same unit, then averaged the three. Their partial AUC was 89.39 percent, the highest among the 26 CNN-only combinations. Even averaging all five CNNs scored slightly lower. Partial AUC emphasizes ranking when false alarms must stay low.

## 7. What changed when XGBoost joined the three CNNs? (3:25–4:12)

XGBoost uses the mean and variability of each mel band. Adding its score to those same three CNNs raised partial AUC to 90.55 percent. The CNNs alone caught 7,620 faults with 576 false alarms. At its own healthy-calibrated cutoff, the hybrid caught 369 more faulty clips and raised 78 more false alarms. Which detector I would use depends on the cost of a missed fault versus an unnecessary inspection.

## 8. Fans and background noise remain the challenge (4:12–4:40)

Most of the extra detections came from fans and pumps. Both ensembles raised most of their false alarms in the noisiest recordings. I compared subsets on a previously inspected test set, so my next test would freeze both detectors and their cutoffs before evaluating fresh sessions.
