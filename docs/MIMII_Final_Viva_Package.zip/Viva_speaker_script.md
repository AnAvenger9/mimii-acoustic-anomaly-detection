# Five-minute viva script

Target finish **4:35**, leaving 25 seconds for transitions. Stop after slide 8. The last two PowerPoint slides are hidden and available for questions.

## 1. Detecting industrial faults from sound (0:00–0:20)

A faulty fan can still sound like the same fan. Could a system trained on healthy recordings detect that change? I tested whether confidence in the identity of a known machine could serve as a fault signal.

## 2. One recording, three noise mixtures (0:20–0:55)

MIMII contains four machine types and four IDs per type. Each ten-second recording appears at three noise levels. I kept the three versions together to prevent leakage. Each clip became a 128-band log-mel spectrogram, normalized using healthy training audio. Every faulty clip was reserved for testing.

## 3. How a machine ID becomes an alarm (0:55–1:30)

For each machine type, I trained a classifier to identify the unit from healthy audio using cross-entropy. At inference, the microphone’s unit is known. A fall in its predicted probability raises the anomaly score, even if that ID stays on top. I set the alarm cutoff at the ninety-fifth percentile of healthy training scores.

## 4. Five CNNs test three design choices (1:30–2:12)

I started with lightweight MobileNet. ResNet has eight residual blocks and EfficientNet has sixteen bottleneck blocks. I fine-tuned these image-pretrained networks on spectrograms. My two acoustic CNNs each have six residual blocks and summarize both average energy and variation over time. Widening the channels increased parameters sevenfold at the same depth.

## 5. Identity accuracy can hide missed faults (2:12–2:41)

ResNet missed only two healthy validation IDs. Yet its alarm missed about thirty percent of faulty test clips. Even a linear classifier using average spectra recognized most healthy IDs. A machine can retain its distinctive sound during a fault, so we need a separate fault-detection test.

## 6. Combining scores improved fault ranking (2:41–3:22)

XGBoost summarizes each band’s energy and variability. I combined that different view with the CNNs by averaging standardized log scores. The highlighted combination led the 57 ensembles. Its AUC of 95.66 percent measures how often faults outrank healthy clips within groups. Its standardized partial AUC was 90.55 percent in the region below ten percent false positives.

## 7. The alarm caught four in five faults (3:22–4:00)

At the fixed threshold, the four-model ensemble caught about eight thousand of the 9,900 faulty clips. It raised 654 false alarms. Overall accuracy was 86.29 percent, and fault recall was 80.70 percent. On the same recordings, that meant 397 more faults detected and 66 fewer false alarms than the five CNNs alone.

## 8. Fans and noise define the next test (4:00–4:35)

Valves and sliders were easier to monitor than fans and pumps. Most false alarms came from the noisiest mixture. Because I compared combinations on a previously inspected test set, the next step is to freeze the ensemble and evaluate new sessions. Healthy machine identity provides a useful fault signal, with clear limits under noise.
